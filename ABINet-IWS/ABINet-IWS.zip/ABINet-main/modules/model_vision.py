import logging
import torch.nn as nn
from fastai.vision import *

from modules.attention import *
from modules.backbone import ResTranformer
from modules.model import Model
from modules.resnet import resnet45


import logging
import torch
import torch.nn as nn
import torch.nn.functional as F
from fastai.vision import *

from modules.attention import *
from modules.backbone import ResTranformer
from modules.model import Model
from modules.resnet import resnet45

import logging
import torch
import torch.nn as nn
import torch.nn.functional as F
from fastai.vision import *

from modules.attention import *
from modules.backbone import ResTranformer
from modules.model import Model
from modules.resnet import resnet45

import logging
import torch
import torch.nn as nn
import torch.nn.functional as F
from fastai.vision import *

from modules.attention import *
from modules.backbone import ResTranformer
from modules.model import Model
from modules.resnet import resnet45

import logging
import torch
import torch.nn as nn
import torch.nn.functional as F
from fastai.vision import *
import os
from datetime import datetime

# 真实掩码+unet1
import logging
import torch
import torch.nn as nn
import torch.nn.functional as F
from fastai.vision import *
import os
from datetime import datetime

from modules.attention import *
from modules.backbone import ResTranformer
from modules.model import Model
from modules.resnet import resnet45

# UNet相关组件
class DoubleConv(nn.Module):
    """改进的双卷积块，添加残差连接"""
    def __init__(self, in_channels, out_channels):
        super().__init__()
        
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.relu1 = nn.ReLU(inplace=True)
        
        self.conv2 = nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm2d(out_channels)
        
        # 残差连接
        if in_channels != out_channels:
            self.residual_conv = nn.Conv2d(in_channels, out_channels, kernel_size=1)
        else:
            self.residual_conv = None
            
        self.relu2 = nn.ReLU(inplace=True)

    def forward(self, x):
        residual = x
        
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu1(x)
        
        x = self.conv2(x)
        x = self.bn2(x)
        
        # 残差连接
        if self.residual_conv is not None:
            residual = self.residual_conv(residual)
        x = x + residual
        
        x = self.relu2(x)
        return x

class Down(nn.Module):
    """下采样：使用步长卷积代替池化，保持更多信息"""
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            DoubleConv(out_channels, out_channels)
        )

    def forward(self, x):
        return self.conv(x)

class Up(nn.Module):
    """上采样：使用转置卷积获得更精确的重建"""
    def __init__(self, in_channels, out_channels):
        super().__init__()
        # 使用转置卷积进行上采样
        self.up = nn.ConvTranspose2d(in_channels, in_channels // 2, kernel_size=2, stride=2)
        self.conv = DoubleConv(in_channels, out_channels)

    def forward(self, x1, x2):
        x1 = self.up(x1)
        
        # 处理尺寸不匹配
        diffY = x2.size()[2] - x1.size()[2]
        diffX = x2.size()[3] - x1.size()[3]
        
        x1 = F.pad(x1, [
            diffX // 2, diffX - diffX // 2,
            diffY // 2, diffY - diffY // 2
        ])
        
        x = torch.cat([x2, x1], dim=1)
        return self.conv(x)

class SimpleUNetForTextRecognition(nn.Module):
    """针对文字识别优化的简化UNet结构"""
    def __init__(self, in_channels, out_channels):
        super().__init__()
        
        # 编码路径 - 减少下采样次数
        self.inc = DoubleConv(in_channels, 64)
        self.down1 = Down(64, 128)
        self.down2 = Down(128, 256)  # 只下采样2次，避免特征图太小
        
        # 瓶颈层
        self.bottleneck = nn.Sequential(
            DoubleConv(256, 512),
            DoubleConv(512, 256)  # 恢复通道数
        )
        
        # 解码路径
        self.up1 = Up(256, 128)
        self.up2 = Up(128, 64)
        
        # 输出卷积
        self.out_conv = nn.Conv2d(64, out_channels, kernel_size=3, padding=1)
        
        # 残差连接
        self.residual = nn.Conv2d(in_channels, out_channels, kernel_size=1) if in_channels != out_channels else nn.Identity()

    def forward(self, x):
        # 保存输入用于残差连接
        identity = x
        
        # 编码路径
        x1 = self.inc(x)          # (N, 64, H, W)
        x2 = self.down1(x1)       # (N, 128, H/2, W/2)
        x3 = self.down2(x2)       # (N, 256, H/4, W/4)
        
        # 瓶颈层
        x4 = self.bottleneck(x3)  # (N, 256, H/4, W/4)
        
        # 解码路径
        x = self.up1(x4, x2)      # (N, 128, H/2, W/2)
        x = self.up2(x, x1)       # (N, 64, H, W)
        
        # 输出
        output = self.out_conv(x)
        
        # 残差连接
        residual = self.residual(identity)
        if residual.shape[2:] != output.shape[2:]:
            residual = F.interpolate(residual, size=output.shape[2:], mode='bilinear', align_corners=True)
        
        return output + residual

class BaseVision(Model):
    def __init__(self, config):
        super().__init__(config)
        self.loss_weight = ifnone(config.model_vision_loss_weight, 1.0)
        self.out_channels = ifnone(config.model_vision_d_model, 512)
        
        # 添加掩码配置
        self.mask_prob = ifnone(getattr(config, 'model_vision_mask_prob', None), 0.1)
        self.mask_ratio = ifnone(getattr(config, 'model_vision_mask_ratio', None), 0.2)
        
        # 调试统计信息和日志文件
        self.mask_stats = {
            'total_forward': 0,
            'mask_applied': 0,
            'mask_skipped_training': 0,
            'mask_skipped_probability': 0,
            'mask_skipped_zero_prob': 0,
            'mask_type_counts': {'feature': 0, 'channel': 0, 'spatial': 0}
        }
        
        # 创建日志文件
        self.log_file = self._setup_log_file()
        self._log_to_file(f"初始化掩码: prob={self.mask_prob}, ratio={self.mask_ratio}")
        print(f"Masking enabled: prob={self.mask_prob}, ratio={self.mask_ratio}")

        # 网络结构初始化
        if config.model_vision_backbone == 'transformer':
            self.backbone = ResTranformer(config)
        else: 
            self.backbone = resnet45()
        
        # 整合UNet结构
        self.unet = SimpleUNetForTextRecognition(
            in_channels=self.out_channels, 
            out_channels=self.out_channels
        )
        
        if config.model_vision_attention == 'position':
            mode = ifnone(config.model_vision_attention_mode, 'nearest')
            self.attention = PositionAttention(
                max_length=config.dataset_max_length + 1,
                mode=mode,
            )
        elif config.model_vision_attention == 'attention':
            self.attention = Attention(
                max_length=config.dataset_max_length + 1,
                n_feature=8*32,
            )
        else:
            raise Exception(f'{config.model_vision_attention} is not valid.')
        
        self.cls = nn.Linear(self.out_channels, self.charset.num_classes)

        if config.model_vision_checkpoint is not None:
            logging.info(f'Read vision model from {config.model_vision_checkpoint}.')
            self.load(config.model_vision_checkpoint)

    def _setup_log_file(self):
        """设置日志文件"""
        log_dir = "mask_logs"
        os.makedirs(log_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_file = os.path.join(log_dir, f"mask_log_{timestamp}.txt")
        
        # 写入文件头
        with open(log_file, 'w', encoding='utf-8') as f:
            f.write(f"掩码应用日志 - 开始时间: {datetime.now()}\n")
            f.write("="*60 + "\n")
            f.write("格式: [序号] 状态 - 详细信息\n")
            f.write("="*60 + "\n\n")
        
        return log_file

    def _log_to_file(self, message, verbose=True):
        """记录到文件并可选打印到控制台"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_message = f"[{timestamp}] {message}"
        
        with open(self.log_file, 'a', encoding='utf-8') as f:
            f.write(log_message + "\n")
        
        if verbose:
            print(log_message)

    def print_mask_stats(self, reset=False, verbose=True):
        """打印掩码统计信息"""
        total = self.mask_stats['total_forward']
        if total == 0:
            return
        
        # 获取当前迭代阶段的掩码概率和比例
        current_iter = total
        current_prob, current_ratio = self._get_current_mask_prob_and_ratio(current_iter)
        
        stats_message = [
            "\n" + "="*60,
            "掩码应用统计:",
            f"总前向传播次数: {total}",
            f"当前迭代阶段: {self._get_stage_name(current_iter)}",
            f"当前掩码概率: {current_prob*100:.1f}%",
            f"当前掩码比例: {current_ratio*100:.1f}%",
            f"掩码应用次数: {self.mask_stats['mask_applied']} ({self.mask_stats['mask_applied']/total*100:.1f}%)",
            f"因非训练模式跳过: {self.mask_stats['mask_skipped_training']}",
            f"因概率未命中跳过: {self.mask_stats['mask_skipped_probability']}",
            f"因概率为0跳过: {self.mask_stats['mask_skipped_zero_prob']}",
            "掩码类型分布:"
        ]
        
        for mask_type, count in self.mask_stats['mask_type_counts'].items():
            if self.mask_stats['mask_applied'] > 0:
                percentage = count / self.mask_stats['mask_applied'] * 100
                stats_message.append(f"  {mask_type}: {count} ({percentage:.1f}%)")
        
        stats_message.append("="*60 + "\n")
        
        full_message = "\n".join(stats_message)
        self._log_to_file(full_message, verbose=verbose)
        
        if reset:
            self.reset_mask_stats()

    def reset_mask_stats(self):
        """重置统计信息"""
        self.mask_stats = {
            'total_forward': 0,
            'mask_applied': 0,
            'mask_skipped_training': 0,
            'mask_skipped_probability': 0,
            'mask_skipped_zero_prob': 0,
            'mask_type_counts': {'feature': 0, 'channel': 0, 'spatial': 0}
        }

    def _get_stage_name(self, iteration):
        """获取当前阶段的名称"""
        if iteration < 500:
            return "早期阶段 (0-500)"
        elif iteration < 1000:
            return "中期阶段 (500-1000)"
        else:
            return "后期阶段 (1000+)"

    def _get_current_mask_prob_and_ratio(self, iteration):
        """根据迭代次数获取当前掩码概率和比例"""
        if iteration < 500:
            return 0.20, 0.20  # 前500次迭代：20%概率，20%比例
        elif iteration < 1000:
            return 0.10, 0.10  # 500-1000次迭代：10%概率，10%比例
        else:
            return 0.00, 0.00  # 1000次及以上：0%概率，0%比例（不调用掩码）

    def _apply_feature_mask(self, features, mask_ratio):
        """对特征图应用随机掩码"""
        batch_size, channels, height, width = features.shape
        
        mask = torch.ones_like(features)
        num_pixels = height * width
        num_mask = int(num_pixels * mask_ratio)
        
        for i in range(batch_size):
            mask_indices = torch.randperm(num_pixels)[:num_mask]
            h_indices = mask_indices // width
            w_indices = mask_indices % width
            mask[i, :, h_indices, w_indices] = 0
        
        masked_features = features * mask
        return masked_features

    def _apply_channel_mask(self, features, mask_ratio):
        """对特征通道应用随机掩码"""
        batch_size, channels, height, width = features.shape
        
        num_mask_channels = max(1, int(channels * mask_ratio))
        channel_mask = torch.ones(batch_size, channels, 1, 1, device=features.device)
        
        for i in range(batch_size):
            mask_channels = torch.randperm(channels)[:num_mask_channels]
            channel_mask[i, mask_channels] = 0
        
        masked_features = features * channel_mask
        return masked_features

    def _apply_spatial_mask(self, features, mask_ratio):
        """应用空间区域掩码"""
        batch_size, channels, height, width = features.shape
        
        masked_features = features.clone()
        
        for i in range(batch_size):
            mask_height = max(1, int(height * mask_ratio))
            mask_width = max(1, int(width * mask_ratio))
            
            start_h = torch.randint(0, height - mask_height + 1, (1,)).item()
            start_w = torch.randint(0, width - mask_width + 1, (1,)).item()
            
            masked_features[i, :, start_h:start_h+mask_height, start_w:start_w+mask_width] = 0
        
        return masked_features

    def _apply_masking_strategy(self, features):
        """统一的掩码策略"""
        self.mask_stats['total_forward'] += 1
        current_iter = self.mask_stats['total_forward']
        current_count = current_iter
        
        # 情况1: 非训练模式
        if not self.training:
            self.mask_stats['mask_skipped_training'] += 1
            self._log_to_file(f"[{current_count}] 跳过掩码: 非训练模式", verbose=False)
            return features
        
        # 根据迭代次数获取当前掩码概率和比例
        current_mask_prob, current_mask_ratio = self._get_current_mask_prob_and_ratio(current_iter)
        
        # 情况2: 当前阶段掩码概率为0
        if current_mask_prob == 0:
            self.mask_stats['mask_skipped_zero_prob'] += 1
            self._log_to_file(f"[{current_count}] 跳过掩码: 当前阶段概率为0 (迭代{current_iter}次)", verbose=False)
            return features
        
        # 情况3: 概率未命中
        rand_val = torch.rand(1).item()
        if rand_val > current_mask_prob:
            self.mask_stats['mask_skipped_probability'] += 1
            self._log_to_file(f"[{current_count}] 跳过掩码: 概率未命中 ({rand_val:.3f} > {current_mask_prob}) [迭代{current_iter}次]", verbose=False)
            return features
        
        # 情况4: 应用掩码
        mask_type = torch.randint(0, 3, (1,)).item()
        mask_types = ["feature", "channel", "spatial"]
        selected_type = mask_types[mask_type]
        
        self.mask_stats['mask_applied'] += 1
        self.mask_stats['mask_type_counts'][selected_type] += 1
        
        # 实时输出（控制台只显示部分信息，文件记录全部）
        log_message = f"[{current_count}] 应用 {selected_type} 掩码 [迭代{current_iter}次, 概率{current_mask_prob}, 比例{current_mask_ratio}]"
        self._log_to_file(log_message, verbose=(current_count % 20 == 0))  # 每20次显示一次
        
        if mask_type == 0:
            return self._apply_feature_mask(features, current_mask_ratio)
        elif mask_type == 1:
            return self._apply_channel_mask(features, current_mask_ratio)
        else:
            return self._apply_spatial_mask(features, current_mask_ratio)

    def forward(self, images, *args):
        # Backbone提取特征
        backbone_features = self.backbone(images)  # (N, E, H, W)
        
        # UNet进一步提取和增强特征
        unet_features = self.unet(backbone_features)  # (N, E, H, W)
        
        # 应用掩码策略
        if self.training:
            unet_features = self._apply_masking_strategy(unet_features)
        
        # 注意力机制
        attn_vecs, attn_scores = self.attention(unet_features)  # (N, T, E), (N, T, H, W)
        logits = self.cls(attn_vecs)  # (N, T, C)
        pt_lengths = self._get_length(logits)

        # 定期打印统计
        if self.mask_stats['total_forward'] % 50 == 0:
            self.print_mask_stats(verbose=True)
        elif self.mask_stats['total_forward'] % 10 == 0:
            self.print_mask_stats(verbose=False)  # 只记录到文件

        return {
            'feature': attn_vecs, 
            'logits': logits, 
            'pt_lengths': pt_lengths,
            'attn_scores': attn_scores, 
            'loss_weight': self.loss_weight, 
            'name': 'vision',
            'backbone_features': backbone_features,
            'unet_features': unet_features
        }

    def close_log_file(self):
        """关闭日志文件前的清理工作"""
        self._log_to_file(f"\n训练结束，总前向传播: {self.mask_stats['total_forward']}")
        self.print_mask_stats(verbose=True)
        self._log_to_file(f"日志文件保存位置: {os.path.abspath(self.log_file)}")



